<?php 
/*
Template Name: Landing
*/
get_header();
?>

<?php include('templates/banner-slideshow.php'); ?>

<?php get_footer(); ?>