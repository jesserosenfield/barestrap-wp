<?php 
/*
Template Name: Flex Layout
*/
get_header();
?>

		<?php include('templates/flex.php'); ?>

<?php get_footer(); ?>