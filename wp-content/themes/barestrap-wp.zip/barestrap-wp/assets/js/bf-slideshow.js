(function($) {
	
	$(document).ready(function(){
		$( '.bf-slideshow' ).cycle();
	});

})(jQuery);