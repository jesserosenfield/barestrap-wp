<?php
	global $flexcontent;
	$txt = get_sub_field('gallery_shortcode');

$flexcontent .= $txt;
?>